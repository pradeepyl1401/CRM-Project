# Demo script (quick)

1. Run server: `python manage.py runserver`
2. Open admin: http://127.0.0.1:8000/admin/ and add some Customers, Leads, Tickets, Campaigns
3. API root: http://127.0.0.1:8000/api/
