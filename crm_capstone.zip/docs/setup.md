# Setup Guide

1. Create virtualenv and install requirements
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. Run migrations
   ```bash
   python manage.py migrate
   ```
3. Create superuser
   ```bash
   python manage.py createsuperuser
   ```
4. Run server
   ```bash
   python manage.py runserver
   ```
