from django.contrib import admin
from .models import Customer, Lead, Ticket, Campaign

admin.site.register(Customer)
admin.site.register(Lead)
admin.site.register(Ticket)
admin.site.register(Campaign)
