from django.test import TestCase
from django.contrib.auth import get_user_model
from .models import Customer

User = get_user_model()

class CustomerModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='tester', password='pass123')

    def test_create_customer(self):
        c = Customer.objects.create(first_name='John', last_name='Doe', email='john@example.com')
        self.assertEqual(str(c).startswith('John'), True)
