from django.urls import path, include
from rest_framework import routers
from .views import CustomerViewSet, LeadViewSet, TicketViewSet, CampaignViewSet

router = routers.DefaultRouter()
router.register(r'customers', CustomerViewSet)
router.register(r'leads', LeadViewSet)
router.register(r'tickets', TicketViewSet)
router.register(r'campaigns', CampaignViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
