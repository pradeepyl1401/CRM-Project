# Contributing

- Fork the repo, create a feature branch and open a Pull Request.
- Run tests and ensure linting before submitting.
