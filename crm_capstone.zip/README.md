# CRM Capstone - Minimal Django + DRF Skeleton

This is a minimal capstone skeleton for a B2C CRM built with Django and Django REST Framework.
It includes basic models (Customer, Lead, Ticket, Campaign), serializers, simple API views,
and a minimal settings configuration using SQLite for local development.

## What's included
- Django project: `crm_project`
- Django app: `crm_app`
- REST endpoints for basic CRUD (customers, leads, tickets, campaigns)
- Dockerfile & docker-compose (basic)
- requirements.txt, .env.example, and simple tests

## How to run (locally)
1. Create a virtualenv: `python -m venv .venv && source .venv/bin/activate`
2. Install dependencies: `pip install -r requirements.txt`
3. Run migrations: `python manage.py migrate`
4. Create superuser: `python manage.py createsuperuser`
5. Run server: `python manage.py runserver`

## Notes
This is a minimal scaffold intended for extension. For production, replace SQLite with Postgres,
add proper secret management, email service, Celery for async tasks, and comprehensive tests.
